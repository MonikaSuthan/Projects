from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.models import User
from django.http import HttpResponse
from .models import *
# Create your views here.
def home(request):
    return render(request,'home.html')
def courses(request):
    return render(request,'courses.html')
def about(request):
    return render(request,'about.html')
def contact(request):
    return render(request,'contact.html')
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        phnumber = request.POST.get('phnumber')  
        email = request.POST.get('email')
        department = request.POST.get('department')
        college = request.POST.get('college')
        district=request.POST.get('district')
        password = request.POST.get('password')
        obj = Register(username=username, phnumber=phnumber, email=email, password=password,
                       department=department,college=college,district=district)
        obj.save()
        return redirect('home')
    return render(request,'register.html') 

        
def login(request):
    if request.method=='POST':
        na=request.POST.get('username')
        pa=request.POST.get('password')
        
        try:
            q=Register.objects.get(username = na)
            if q.password == pa:
                return redirect('courses')
            
            else:
                return HttpResponse("Invalid password")
        except:
            return HttpResponse("Something went wrong")

    return render(request,'login.html') 
def table(request):
    q=Register.objects.all()  
    return render(request,'table.html',{'data':q})  
def delete(request,id):
    Register.objects.filter(id=id).delete()
    return redirect('table')
def update(request,id):
    a=Register.objects.get(id=id)
    return render(request,'update.html',{'obj':a})
def update_field(request,id):
    if request.method=='POST':
        username=request.POST.get('username')
        phnumber=request.POST.get('phnumber')
        email=request.POST.get('email')
        
        department=request.POST.get('department')
        college=request.POST.get('college')
        district=request.POST.get('district')
        password=request.POST.get('password')
        obj=Register.objects.get(id=id)
        obj.username = username
        obj.phnumber = phnumber
        obj.email = email
        obj.district=district
        obj.password = password
        obj.department = department
        obj.college = college
        obj.save()
        return redirect('table')